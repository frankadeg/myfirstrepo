﻿using Xamarin.Forms;

namespace PartsUnlimited.Views
{
    public partial class SettingsPage : ContentPage
    {
        public SettingsPage()
        {
            InitializeComponent();
        }
    }
}
